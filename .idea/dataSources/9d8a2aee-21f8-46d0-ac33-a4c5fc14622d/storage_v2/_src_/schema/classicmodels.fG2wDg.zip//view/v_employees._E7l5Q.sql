create definer = root@localhost view v_employees as
select `e`.`employeeNumber` AS `employeeNumber`,
       `e`.`lastName`       AS `lastName`,
       `e`.`firstName`      AS `firstName`,
       `e`.`extension`      AS `extension`,
       `e`.`email`          AS `email`,
       `e`.`officeCode`     AS `officeCode`,
       `e`.`reportsTo`      AS `reportsTo`,
       `e`.`jobTitle`       AS `jobTitle`,
       `o`.`city`           AS `officeCity`
from (`classicmodels`.`employees` `e`
         join `classicmodels`.`offices` `o` on ((`e`.`officeCode` = `o`.`officeCode`)));

