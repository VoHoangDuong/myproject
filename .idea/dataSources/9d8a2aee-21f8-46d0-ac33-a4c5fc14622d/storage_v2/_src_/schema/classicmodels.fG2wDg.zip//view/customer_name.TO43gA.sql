create definer = root@localhost view customer_name as
select `classicmodels`.`customers`.`customerName` AS `Ten_KH`, `classicmodels`.`customers`.`phone` AS `So_DT`
from `classicmodels`.`customers`;

